#!/bin/bash

echo "1️⃣ Disinstallo eventuale ctcdecode esistente..."
pip uninstall -y ctcdecode

echo "2️⃣ Clono ctcdecode..."
rm -rf ctcdecode
git clone --recursive https://github.com/parlance/ctcdecode.git
cd ctcdecode

echo "3️⃣ Imposto variabili ambiente..."
export CFLAGS="-I$CONDA_PREFIX/include"
export CXXFLAGS="-I$CONDA_PREFIX/include"
export LDFLAGS="-L$CONDA_PREFIX/lib"
export CMAKE_PREFIX_PATH=$CONDA_PREFIX

echo "4️⃣ Compilo ctcdecode con cmake..."
mkdir -p build && cd build
cmake .. && make -j$(nproc)

echo "5️⃣ Installo in modo pulito..."
cd ..
pip install .
