#!/bin/bash

set -e

# === CONFIGURAZIONE ===
FFMPEG_DIR=$HOME/ffmpeg_build_output
NUM_CORES=$(nproc)
FFMPEG_SRC=~/ffmpeg_build/ffmpeg

# === 1. Clona e compila FFmpeg se non già presente ===
if [ -d "$FFMPEG_SRC" ] && [ -f "$FFMPEG_DIR/lib/libavcodec.so" ]; then
    echo "⚠️ FFmpeg già compilato e installato in $FFMPEG_DIR. Skip."
else
    echo "Clonazione e compilazione di FFmpeg..."
    mkdir -p ~/ffmpeg_build && cd ~/ffmpeg_build

    if [ ! -d "$FFMPEG_SRC" ]; then
        git clone https://git.ffmpeg.org/ffmpeg.git ffmpeg
    else
        echo "⚠️ Repository FFmpeg già presente. Skip clonazione."
    fi

    cd ffmpeg
    ./configure --prefix=$FFMPEG_DIR --enable-shared
    make -j$NUM_CORES
    make install
fi

# === 2. Setta variabili d'ambiente ===
echo "Esportazione dei path..."
export PKG_CONFIG_PATH=$FFMPEG_DIR/lib/pkgconfig
export LD_LIBRARY_PATH=$FFMPEG_DIR/lib:$LD_LIBRARY_PATH
export C_INCLUDE_PATH=$FFMPEG_DIR/include
export LIBRARY_PATH=$FFMPEG_DIR/lib

# Aggiungi anche al profilo utente per uso futuro (solo se non già presente)
if ! grep -q "FFmpeg build custom path" ~/.bashrc; then
    echo "Aggiornamento .bashrc..."
    echo "# FFmpeg build custom path" >> ~/.bashrc
    echo "export PKG_CONFIG_PATH=$FFMPEG_DIR/lib/pkgconfig" >> ~/.bashrc
    echo "export LD_LIBRARY_PATH=$FFMPEG_DIR/lib:\$LD_LIBRARY_PATH" >> ~/.bashrc
    echo "export C_INCLUDE_PATH=$FFMPEG_DIR/include" >> ~/.bashrc
    echo "export LIBRARY_PATH=$FFMPEG_DIR/lib" >> ~/.bashrc
else
    echo "⚠️ Variabili già presenti in .bashrc. Skip."
fi

# === 3. Installa Lintel da Git (upgrade forzato) ===
echo "Installazione o aggiornamento di Lintel..."
pip install --upgrade git+https://github.com/dukebw/lintel.git

echo "✅ Installazione completata con successo!"
