from setuptools import setup, Extension, find_packages
import os

# Percorso alla build locale di FFmpeg
FFMPEG_DIR = os.path.expanduser('~/ffmpeg_build_output')

# Estensione C
lintel_module = Extension(
    '_lintel',
    define_macros=[
        ('MAJOR_VERSION', '1'),
        ('MINOR_VERSION', '0'),
        ('PY_SSIZE_T_CLEAN', None),  # per compatibilità con Python >= 3.9
    ],
    undef_macros=['NDEBUG'],
    include_dirs=[
        os.path.join(FFMPEG_DIR, 'include'),  # include FFmpeg headers
        'lintel',  # headers del progetto
    ],
    library_dirs=[
        os.path.join(FFMPEG_DIR, 'lib'),
    ],
    runtime_library_dirs=[
        os.path.join(FFMPEG_DIR, 'lib'),
    ],
    libraries=[
        'avformat', 'avcodec', 'avutil', 'swscale', 'swresample'
    ],
    sources=[
        'lintel/py_ext/lintelmodule.c',
        'lintel/core/video_decode.c'
    ],
    extra_compile_args=['-O2', '-Wall', '-fPIC'],
    extra_link_args=[f'-Wl,-rpath,{os.path.join(FFMPEG_DIR, "lib")}']
)

# Setup
setup(
    name='Lintel',
    version='1.0',
    author='Brendan Duke',
    author_email='brendanw.duke@gmail.com',
    description='Video decoding package using FFmpeg C API.',
    long_description="""
        Extension for loading video from Python, by directly
        using the FFmpeg C API.
    """,
    ext_modules=[lintel_module],
    packages=find_packages(),
    install_requires=[
        'Click',
        'numpy',
    ],
    entry_points={
        'console_scripts': [
            'lintel_test=lintel.test.loadvid_test:loadvid_test',
        ],
    },
    py_modules=['lintel.test.loadvid_test'],
    url='https://brendanduke.ca',
    license='Apache 2.0',
)
